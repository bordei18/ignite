package com.example.webfluxdemo.scheduler;

import com.example.webfluxdemo.model.Tweet;
import com.example.webfluxdemo.repository.TweetRepository;
import com.example.webfluxdemo.repository.TweetRepositoryNoReactive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

/**
 * Created by borde on 05/15/2018.
 */
@Component
public class InsertTweets {

    @Autowired
    private TweetRepositoryNoReactive tweetRepository;

    @Scheduled(fixedDelay = 1000)
    public void insertTweet() {

        Tweet tweet = new Tweet();
        tweet.setId(UUID.randomUUID().toString());
        tweet.setCreatedAt(new Date());
        tweet.setText("my tweet " + tweet.getId());

        tweetRepository.save(tweet);

        System.out.println("Mongo Insert " + tweetRepository.count());
    }


}
